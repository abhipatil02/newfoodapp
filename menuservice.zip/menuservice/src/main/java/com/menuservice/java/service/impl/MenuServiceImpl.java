package com.menuservice.java.service.impl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.menuservice.java.dto.FoodResponseDto;
import com.menuservice.java.entity.Menu;
import com.menuservice.java.repo.MenuRepository;
import com.menuservice.java.service.MenuService;

@Service
public class MenuServiceImpl implements MenuService {
	@Autowired
	MenuRepository menuRepository;

	@Override
	public FoodResponseDto getFoodItemByName(String foodName) {
		Menu menu = new Menu();
		FoodResponseDto foodResponseDto = new FoodResponseDto();
		Optional<Menu> optionalFood = menuRepository.findByFoodNameLike(foodName);

		if (optionalFood.isPresent()) {
			menu = optionalFood.get();

		}
		BeanUtils.copyProperties(menu, foodResponseDto);
		return foodResponseDto;

	}
}
