package com.menuservice.java.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.menuservice.java.dto.FoodResponseDto;
import com.menuservice.java.service.MenuService;

@RestController
public class FoodController {
	
	@Autowired
	MenuService menuService;	

	@GetMapping("/foodItems/{foodName}")
	public FoodResponseDto getFoodItemByName(@PathVariable String foodName) {
		return menuService.getFoodItemByName(foodName);

	}

}
